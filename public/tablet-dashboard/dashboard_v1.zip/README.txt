════════════════════════════════════════════
  タブレット情報モニター ダッシュボード
════════════════════════════════════════════

■ ファイル構成
  weather.html  ── 時刻・天気・ニュースPickup
  news.html     ── ニュース（テクノロジー/ビジネス/エンタメ・ガジェット）
  finance.html  ── 金融（日経・TOPIX・BTC・ドル円・ユーロ円）
  calendar.html ── カレンダー（Googleカレンダー連携）
  sports.html   ── スポーツ（野球/サッカー/バスケ/その他）
  settings.html ── 設定

■ セットアップ手順

【Android タブレット（推奨）】
1. 6ファイルをすべてダウンロード
2. タブレットの「Download」フォルダに転送
   （Google Drive / USB ケーブル どちらでも可）
3. Fully Kiosk Browser（無料）をインストール
4. 「Pick a File」で weather.html を選択
5. フルスクリーンで表示されます

【PC ブラウザで確認する場合】
  weather.html をダブルクリックして開くだけ

■ 初回設定（settings.html から行います）
  🎨 テーマ    ：ダーク / ライト / E-Paper を選択
  🌤 天気地域  ：都市名を検索して選択（例：渋谷区）
  📰 ニュース  ：表示するカテゴリをON/OFF
  📅 カレンダー：Google カレンダーの iCal URL を貼り付け

■ カレンダー URL の取得方法
  1. Google カレンダーを開く
  2. カレンダー名の右「⋮」→「設定と共有」
  3. 「カレンダーの統合」→「iCal 形式の公開 URL」をコピー
  4. settings.html の カレンダー欄に貼り付けて保存

  ※ GoogleカレンダーはブラウザからGoogleへ直接つなげないため、
    無料の中継サービス（r.jina.ai 等）を経由して取得します。
    そのため、カレンダーのURLは中継サービスにも送信されます。
    ・URLは他人に教えない「秘密のアドレス」です。気になる場合は、
      Googleカレンダーで専用のカレンダーを作り、公開したくない
      予定は入れないでください。
    ・中継サービスが一時的に使えないときは、前回取得した予定を
      表示し続けます（画面に取得時刻が出ます）。

■ 動作確認済み環境
  Huawei MediaPad M3 Lite（Android 7〜8）
  Chrome 119 / Fully Kiosk Browser（無料版）

■ 使用サービス（すべて無料）
  天気    : Open-Meteo（api.open-meteo.com）
  ニュース : RSS2JSON（api.rss2json.com）
  株価・為替: TradingView ウィジェット
  スポーツ : 各スポーツニュースサイトのRSS（RSS2JSON経由）
  カレンダー: r.jina.ai（中継）／日本の祝日: holidays-jp.github.io
  地域検索 : Open-Meteo Geocoding

■ 設定データについて
  すべての設定はお使いの端末の localStorage に保存されます。
  外部サーバーへの個人情報送信は一切ありません。

════════════════════════════════════════════
